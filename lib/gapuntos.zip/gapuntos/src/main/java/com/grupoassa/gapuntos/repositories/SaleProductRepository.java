package com.grupoassa.gapuntos.repositories;


public class SaleProductRepository extends DBConnectionManager{
    public SaleProductRepository() {
        super();
    }
    
    /// NO se llega a usar esta clase y tampoco se lelg� a crear su tabla.
}
