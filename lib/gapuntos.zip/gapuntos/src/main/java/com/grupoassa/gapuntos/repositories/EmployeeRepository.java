package com.grupoassa.gapuntos.repositories;


import com.grupoassa.gapuntos.entidades.Empleado;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import java.text.ParseException;
import java.text.SimpleDateFormat;

import java.util.ArrayList;
import java.util.List;

public class EmployeeRepository extends UserRepository{

    public EmployeeRepository() {
        super();
    }
    // Realiza la insercion de datos iniciales
    public void insertEmployeeInitial(String sql) {
            /*  String sql = "INSERT INTO Employee (id,name,lastName,mail,password,category,admissionDate,points) VALUES('1','Juan','Lopez'),"
                            + "('2','Lucas','Fernandez')," 
                            + "('3','Roberto','Gutierrez');"; */
            try (PreparedStatement pstmt = this.conn.prepareStatement(sql)) {
                    pstmt.executeUpdate();
                    System.out.println("Insert Initial Employee OK");
            } catch (SQLException e) {
                    System.out.println(e.getMessage());
            }
    }

    // Inserta un empleado, pasando como parametro una instancia de empleado
    public void insertEmployee(Empleado employee) {
            String sql = "INSERT INTO Employee (idEmployee,name,lastName,mail,password,category,admissionDate,points) VALUES(?,?,?,?,?,?,?,?)";
        try {
            this.preparedStatementInsert(sql, employee).executeUpdate();
        } catch (SQLException e) {
        }

    }
    
    // Retorna un empleado buscandolo por id
    public Empleado getEmployee(int id) {
        String sql = "SELECT *  FROM Employee WHERE idEmployee=?"; 
        Empleado employee = null;
        SimpleDateFormat nowFormat = new SimpleDateFormat("dd/MM/yyyy");
        try (PreparedStatement pstmt = this.conn.prepareStatement(sql)) {
                pstmt.setInt(1, id);
                ResultSet rs = pstmt.executeQuery();
            //System.out.println(rs.getDate("admissionDate"));
                java.util.Date date = nowFormat.parse(rs.getString("admissionDate"));
                employee = new Empleado(rs.getInt("idEmployee"), rs.getString("name"),rs.getString("lastName"),rs.getString("mail"),rs.getString("password"),rs.getString("category"), 
                                        date,rs.getInt("points"));
        } catch (SQLException e) {
                System.out.println(e.getMessage());
        } catch (ParseException e) {
        }
        return employee;
    }

    //Verifica si el empleado existe previamente
    //Si existe realiza el update, sino existe lo inserta en la base de datos
    public void insertOrUpdateObject(Object chain) {
            Empleado employee = (Empleado) chain;
            Empleado existEmployee = this.getEmployee(employee.getDniUsuario());
            if (existEmployee == null) {//Si la variable existEmployee es null es porque no existe el empleado en la BD.
                    this.insertEmployee(employee);
            } else {
                    String sql = "UPDATE Employee SET name=?,lastName=?,mail=?,password=?,category=?,admissionDate=?,points=? WHERE idEmployee=?";
            try {
                this.preparedStatementUpdate(sql, employee).executeUpdate();
            } catch (SQLException e) {
            }
        }
    }



    // Retorna una lista de con todos los empleados en la base
    public List<Empleado> getEmployees() {
            String sql = "SELECT *  FROM Employee";
            List<Empleado> employees = new ArrayList<Empleado>();
            SimpleDateFormat nowFormat = new SimpleDateFormat("dd/MM/yyyy");
            try (Statement stmt = this.conn.createStatement();
                            ResultSet rs = stmt.executeQuery(sql)) {
                    while (rs.next()) {
                            java.util.Date date = null;
                try {
                    date = nowFormat.parse(rs.getString("admissionDate"));
                } catch (ParseException e) {
                }
                Empleado employee = new Empleado(rs.getInt("idEmployee"), rs.getString("name"), rs.getString("lastName"),rs.getString("mail"),
                                                 rs.getString("password"),rs.getString("category"), date,rs.getInt("points"));
                            employees.add(employee);
                    }
            } catch (SQLException e) {
                    System.out.println(e.getMessage());
            }
            return employees;
    }

    @Override
    public PreparedStatement preparedStatementInsert(String sql, Object thing) throws SQLException {
        PreparedStatement pstmt = null;
        Empleado employee = (Empleado) thing;
        pstmt = this.conn.prepareStatement(sql);
        pstmt.setInt(1, employee.getDniUsuario());
        pstmt.setString(2, employee.getNombre());
        pstmt.setString(3, employee.getApellido());
        pstmt.setString(4, employee.getMail());
        pstmt.setString(5, employee.getContrasenia());
        pstmt.setString(6, employee.getCategoria());
        pstmt.setString(7, employee.dateToString(employee.getFechaDeIngreso()));
        pstmt.setInt(8, employee.getPuntos());
        return pstmt;
    }
    
    @Override
    public PreparedStatement preparedStatementUpdate(String sql, Object thing) throws SQLException {
        PreparedStatement pstmt = null;
        Empleado employee = (Empleado) thing;
        pstmt = this.conn.prepareStatement(sql);
        pstmt.setInt(8, employee.getDniUsuario());
        pstmt.setString(1, employee.getNombre());
        pstmt.setString(2, employee.getApellido());
        pstmt.setString(3, employee.getMail());
        pstmt.setString(4, employee.getContrasenia());
        pstmt.setString(5, employee.getCategoria());
        pstmt.setString(6, employee.dateToString(employee.getFechaDeIngreso()));
        pstmt.setInt(7, employee.getPuntos());
        return pstmt;
    }
}
