package com.grupoassa.gapuntos.repositories;

import com.grupoassa.gapuntos.interfaces.Insertable;

import com.grupoassa.gapuntos.entidades.Operacion;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import java.text.ParseException;
import java.text.SimpleDateFormat;

import java.util.ArrayList;
import java.util.List;


public class OperationRepository extends DBConnectionManager implements Insertable{
    /*  private Connection conn; */
    
    public OperationRepository() {
        super();
        /* this.conn = conn; */
    }

    // Realiza la insercion de datos iniciales
    public void insertOperationInitial(String sql) {
            /*  String sql = "INSERT INTO Operation(id,name,lastName) VALUES(1,'Juan','Lopez'),"
                            + "(2,'Lucas','Fernandez')," 
                            + "(3,'Roberto','Gutierrez');"; */
            try (PreparedStatement pstmt = this.conn.prepareStatement(sql)) {
                    pstmt.executeUpdate();
                    System.out.println("Insert Initial Operation OK");
            } catch (SQLException e) {
                    System.out.println(e.getMessage());
            }
    }

    // Inserta un cliente, pasando como parametro una instancia de cliente
    public void insertOperation(Operacion operation) {
            String sql = "INSERT INTO Operation(idOperation,IdProduct,idEmployee,transactionDate,exchangePoints) VALUES(?,?,?,?,?)";

            try (PreparedStatement pstmt = this.conn.prepareStatement(sql)) {
                    pstmt.setInt(1, operation.getIdOperation());
                    pstmt.setInt(2, operation.getIdProducto());
                    pstmt.setInt(3, operation.getDniEmpleado());
                    pstmt.setString(4, operation.getDateToString(operation.getFechaTransaccion()));
                    pstmt.setInt(5, operation.getPuntosCanje());
                    pstmt.executeUpdate();
                    System.out.println("Insert Operation OK");
            } catch (SQLException e) {
                    System.out.println(e.getMessage());
            }
    }

    //Verifica si el cliente existe previamente
    //Si existe realiza el update, sino existe lo inserta en la base de datos
    @Override
    public void insertOrUpdateObject(Object chain) {
            Operacion operation = (Operacion) chain;
            Operacion existOperation = this.getOperation(operation.getIdOperation());
            if (existOperation == null) {//Si la variable existOperation es null es porque no existe la operacion en la BD.
                    this.insertOperation(operation);
            } else {
                    String sql = "UPDATE Operation SET idProduct=?, idEmployee=?, transactionDate=?, exchangePoints=? WHERE idOperation=?";
                    try (PreparedStatement pstmt = this.conn.prepareStatement(sql)) {
                        pstmt.setInt(5, operation.getIdOperation());
                        pstmt.setInt(1, operation.getIdProducto());
                        pstmt.setInt(2, operation.getDniEmpleado());
                        pstmt.setString(3, operation.getDateToString(operation.getFechaTransaccion()));
                        pstmt.setInt(4, operation.getPuntosCanje());
                            System.out.println("Update Operation OK");
                    } catch (SQLException e) {
                            System.out.println(e.getMessage());
                    }
            }
    }

    // Retorna un cliente buscandolo por id
    public Operacion getOperation(int id) {
            String sql = "SELECT *  FROM Operation WHERE idOperation=?";
           Operacion operation = null;
            SimpleDateFormat nowFormat = new SimpleDateFormat("dd/MM/yyyy");
            try (PreparedStatement pstmt = this.conn.prepareStatement(sql)) {
                    pstmt.setInt(1, id);
                    ResultSet rs = pstmt.executeQuery();
                    java.util.Date date = nowFormat.parse(rs.getString("transactionDate"));
                    operation = new Operacion(rs.getInt("idOperation"), rs.getInt("idEmployee"), rs.getInt("idProduct"), date, rs.getInt("exchangePoints"));
            } catch (SQLException e) {
                    System.out.println(e.getMessage());
            } catch (ParseException e) {
        }
        return operation;
    }

    // Retorna una lista de con todos los clientes en la base
    public List<Operacion> getOperations() {
            String sql = "SELECT *  FROM Operation"; 
            List<Operacion> operations = new ArrayList<Operacion>();
            SimpleDateFormat nowFormat = new SimpleDateFormat("dd/MM/yyyy");
            
            try (Statement stmt = this.conn.createStatement();
                            ResultSet rs = stmt.executeQuery(sql)) {
                    while (rs.next()) {
                            java.util.Date date = null;
                        try {
                            String dateR=rs.getString("transactionDate");
                            date = nowFormat.parse(dateR);
                        } catch (ParseException e) {
                        }//// Arreglar lo de producto y empelado en operaciones.
                        Operacion operation = new Operacion(rs.getInt("idOperation"), rs.getInt("idEmployee"), rs.getInt("idProduct"), date,
                                  rs.getInt("exchangePoints"));
                        operations.add(operation);
                    }
            } catch (SQLException e) {
                    System.out.println(e.getMessage());
            }
            return operations;
    }
    
    
    //Escribe en un archivo los registros de una tabla.
    /*  public void writeFileOperations(List<Operacion> rows){
        Path path = Paths.get("outputfile.txt");
        try (BufferedWriter br = Files.newBufferedWriter(path,
                    Charset.defaultCharset(), StandardOpenOption.CREATE)) {
                 for (Operacion line : rows) {
                    br.write(line.toString());
                    br.newLine();
                 }
              } catch (Exception e) {
                 e.printStackTrace();
                }
    
    } */
}
