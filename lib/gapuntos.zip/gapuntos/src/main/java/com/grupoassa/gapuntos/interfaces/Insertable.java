package com.grupoassa.gapuntos.interfaces;

//// Se creo para aplicar a todos los repository, pero no se llego a hacer.
public interface Insertable {
    
    public void insertOrUpdateObject(Object chain);
}
