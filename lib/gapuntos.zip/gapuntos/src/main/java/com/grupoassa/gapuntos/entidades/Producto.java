package com.grupoassa.gapuntos.entidades;

public class Producto implements Comparable{
    private Integer idProducto;
    private Integer stock;
    private String nombreProd;
    private String descripcion;
    private int vPuntos;
    
    public Producto(Integer idProducto, String nombreProd, String descripcion, int stock, int vPuntos) {
        this.idProducto = idProducto;
        this.nombreProd = nombreProd;
        this.descripcion = descripcion;
        this.stock = stock; // Hay que ver que se hace con esto;
        this.vPuntos = vPuntos; // ver si esto queda aca o no.
    }


    public void setVPuntos(int vPuntos) {
        this.vPuntos = vPuntos;
    }

    public int getVPuntos() {
        return this.vPuntos;
    }

    public void setStock(Integer stock) {
        this.stock = stock;
    }

    public Integer getStock() {
        return stock;
    }

        public void setIdProducto(int idProducto) {
        this.idProducto = idProducto;
    }

    public int getIdProducto() {
        return idProducto;
    }

    public void setNombreProd(String nombreProd) {
        this.nombreProd = nombreProd;
    }

    public String getNombreProd() {
        return nombreProd;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getDescripcion() {
        return descripcion;
    }

    @Override
    public String toString(){
        return " cod.: "+ this.idProducto + " >> "+this.nombreProd +" "+ this.descripcion+" | "+this.stock +" unidades | "+ this.vPuntos+" puntos\n";
    }
    @Override
    public boolean equals(Object p){
        return ((Producto)p).getNombreProd().equals(this.getNombreProd());
    }
    
    @Override
    public int hashCode(){
        return this.getNombreProd().hashCode();
    }
    
    @Override
    public int compareTo(Object o) {
        return this.stock.compareTo(((Producto)o).getStock());
    }
    
    

}
