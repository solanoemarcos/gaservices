/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.grupoassa.gapuntos.entidades;

/**
 *
 * @author Marcos
 */
public class CategoriaEmpleado {
    private String categoria;
    private Integer puntos;
    private Integer IdCategoria;

    public CategoriaEmpleado(){
        
    }
    
    public CategoriaEmpleado (Integer idCategoria, String categoria, Integer puntos){
        this.IdCategoria = idCategoria;
        this.puntos = puntos;
        this.categoria = categoria;
    }
    
    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public Integer getPuntos() {
        return puntos;
    }

    public void setPuntos(Integer puntos) {
        this.puntos = puntos;
    }

    public Integer getIdCategoria() {
        return IdCategoria;
    }

    public void setIdCategoria(Integer IdCategoria) {
        this.IdCategoria = IdCategoria;
    }
}
