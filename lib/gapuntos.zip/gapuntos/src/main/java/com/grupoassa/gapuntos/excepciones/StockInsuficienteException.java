package com.grupoassa.gapuntos.excepciones;

public class StockInsuficienteException extends Exception{
    private String mensaje = "No hay stock del producto.";
    
    public StockInsuficienteException() {
        super();
    }
     
/*     public void setMessage(String msj){
        this.mensaje = msj;
    } */
    @Override
    public String getMessage(){
        return this.mensaje;
    }

}
