package com.grupoassa.gapuntos.excepciones;

public class PuntosInsuficientesException extends Exception{
    public PuntosInsuficientesException() {
        super();
    }
    
    @Override
    public String getMessage(){
        return "No se puede realizar el canje. Puntos insuficientes.";
    }

}
