package com.grupoassa.gapuntos.entidades;

import java.util.Set;

public class ProductoPaquete extends Producto {
    //No puede tener productos repetidos.
    //private ArrayList<Producto> combo;
    public Set<Producto> combo;


    public ProductoPaquete(Integer idProd, String nombre, String descripcion, Set<Producto> pack){
    super(idProd,nombre,descripcion,0,0);
        this.combo = pack;
    }
    

    public Set<Producto> getCombo() {
        return this.combo;
    }
    
    @Override
    public int getVPuntos(){
        int value = 0;
        for(Producto p : this.combo)
            value += p.getVPuntos();
        return value;
    }
    
    public String getDescripcionPaquete(){
        String descripcion = "";
        for(Producto p : this.combo){
            descripcion += p.getDescripcion() + "-";
        }
        return "hola";
    }
    
}