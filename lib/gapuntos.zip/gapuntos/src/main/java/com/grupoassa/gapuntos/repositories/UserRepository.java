package com.grupoassa.gapuntos.repositories;

import com.grupoassa.gapuntos.interfaces.Insertable;


import java.sql.PreparedStatement;
import java.sql.SQLException;

public abstract class UserRepository extends DBConnectionManager implements Insertable{
    public UserRepository() {
        super();
    }
    
    public abstract PreparedStatement preparedStatementInsert(String sql, Object thing) throws SQLException;
    
    public abstract PreparedStatement preparedStatementUpdate(String sql, Object thing) throws SQLException;

    public abstract void insertOrUpdateObject(Object chain);
}
