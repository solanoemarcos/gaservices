package com.grupoassa.gapuntos.entidades;

import java.util.Date;

public class ProductoOferta extends Producto{
    private Date fechaVto;
    private Double ptjeDesc;
    
    public ProductoOferta(Integer idProd, Producto prodOf, Date fechaVto, Double ptjeDesc) {
        super(idProd,prodOf.getNombreProd(),prodOf.getDescripcion(),0,0);
        this.fechaVto = fechaVto;
        this.ptjeDesc = ptjeDesc;
        
    }

    public void setFechaVto(Date fechaVto) {
        this.fechaVto = fechaVto;
    }
    /**
     *
     * @return devuelve la fecha de vto en un dato de tipo Date.
     */
    
    public Date getFechaVto() {
        return fechaVto;
    }
    /**
     *
     * @param ptjeDesc 
     */
    
    public void setPtjeDesc(Double ptjeDesc) {
        this.ptjeDesc = ptjeDesc;
    }

    public Double getPuntosPtjeDesc(Date today) {
        double ptje = super.getVPuntos()  - calcularPuntos();
        if(!(this.verificarFecha(today)))
            ptje = super.getVPuntos();
        return ptje;
    }
    
    private double calcularPuntos(){
        return super.getVPuntos() * this.ptjeDesc /100;
    }
    public Double getPtjeDesc() {
        return ptjeDesc;
    }
    
    public boolean verificarFecha(Date today){
        boolean able = false;
        if(this.fechaVto.after(today))
            able = true;
        return able;
    }
}
