package com.grupoassa.gapuntos.entidades;

public abstract class Usuario {
    protected Integer dniUsuario;
    protected String nombre;
    protected String apellido;
    protected String mail;
    protected String contrasenia;
    
    public Usuario(Integer dniUsuario, String nombre, String apellido, String mail, String contrasenia) {
        this.dniUsuario = dniUsuario;
        this.nombre = nombre;
        this.apellido = apellido;
        this.mail = mail;
        this.contrasenia = contrasenia;
    }
    
    public Usuario(Integer dniUsuario,String apellido, String mail, String contrasenia) {
        this.dniUsuario = dniUsuario;
        this.nombre = " ";
        this.apellido = apellido;
        this.mail = mail;
        this.contrasenia = contrasenia;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getNombre() {
        return nombre;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getApellido() {
        return apellido;
    }

    public void setIdUsuario(Integer dniUsuario) {
        this.dniUsuario = dniUsuario;
    }

    public Integer getDniUsuario() {
        return dniUsuario;
    }

    public void setMail(String mail) {
        this.mail = mail;
    }

    public String getMail() {
        return mail;
    }

    public void setContrasenia(String contrasenia) {
        this.contrasenia = contrasenia;
    }

    public String getContrasenia() {
        return contrasenia;
    }
    
    @Override
    public String toString(){
        return this.dniUsuario+" "+this.nombre +" "+this.apellido+" "+this.contrasenia+" "+this.mail;
    }
}
