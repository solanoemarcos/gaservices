package com.grupoassa.gapuntos.repositories;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class DBConnectionManager {

	//En esta variable estatica definimos el nombre de la base de datos
	//Se creara el archivo BancoDatos, en el directorio raiz de nuestro proyecto.
	private static final String DB_NAME = "DB_gAClub";
	protected Connection conn;
	
	
	//Llama al constructo default del padre e invoca al metodo connect()
	public DBConnectionManager() {
		super();
		this.conn = this.connect();
                this.initDataBase();
	}

	//Crea la base de datos 
	private Connection connect() {		 
		Connection connection= null;
		try {
			connection = DriverManager.getConnection("jdbc:sqlite:" + DB_NAME);			
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		return connection;
	}
        
        // Create all tables.
        private void initDataBase(){
            this.createEmployeeTable();
            this.createAdminTable();
            this.createOperationTable();
            this.createProductTable();
            this.createPackageProductTable();
            //this.createCategoryTable();
            
        }
        
        // Se crea la tabla usuario con el campo id como clave primaria
        private void createEmployeeTable() {
            String sql = " CREATE TABLE IF NOT EXISTS Employee (\n"
                            + "     idEmployee int PRIMARY KEY NOT NULL,\n"
                            + "     name text NOT NULL,\n"
                            + "     lastName text NOT NULL, \n"
                            + "     mail text NOT NULL, \n"
                            + "     password text NOT NULL, \n"
                            + "     category text NOT NULL, \n"
                            + "     admissionDate Date, \n"
                            + "     points int NOT NULL \n" + ")";

            try (Statement stmt = this.conn.createStatement()) {
                    stmt.execute(sql);
            } catch (SQLException e) {
                    System.out.println(e.getMessage());
            }
        }
        
        private void createAdminTable() {
            String sql = " CREATE TABLE IF NOT EXISTS Admin (\n"
                        + "     idAdmin int PRIMARY KEY NOT NULL,\n"
                        + "     name text NOT NULL,\n"
                        + "     lastName text NOT NULL, \n"
                        + "     mail text NOT NULL, \n"
                        + "     password text NOT NULL \n" + ")";

            try (Statement stmt = this.conn.createStatement()) {
                    stmt.execute(sql);
            } catch (SQLException e) {
                    System.out.println(e.getMessage());
            }
        }
        
        // Se crea la tabla operacion con el campo id como clave primaria
        private void createOperationTable() {
            String sql = " CREATE TABLE IF NOT EXISTS Operation (\n"
                            + "     idOperation int PRIMARY KEY NOT NULL,\n"
                            + "     idProduct int NOT NULL,\n"
                            + "     idEmployee int NOT NULL, \n"
                            + "     transactionDate text NOT NULL, \n"
                            + "     exchangePoints int NOT NULL \n" + ")";

            try (Statement stmt = this.conn.createStatement()) {
                    stmt.execute(sql);
            } catch (SQLException e) {
                    System.out.println(e.getMessage());
            }
        }
        
        // Se crea la tabla producto con el campo id como clave primaria
        private void createProductTable() {
            String sql = " CREATE TABLE IF NOT EXISTS Product (\n"
                        + "     idProduct int PRIMARY KEY NOT NULL,\n"
                        + "     name text NOT NULL, \n"
                        + "     description text NOT NULL, \n"
                        + "     stock int NOT NULL,\n"
                        + "     valuePoints int NOT NULL \n"+ ")";
                        /*                         + "     dueDate text NOT NULL \n"
                        + "     discountRate double NOT NULL \n" + ")"; */

            try (Statement stmt = this.conn.createStatement()) {
                stmt.execute(sql);
            } catch (SQLException e) {
                System.out.println(e.getMessage());
            }
        }
        
    // Se crea la tabla producto paquete con el campo id como clave primaria
    private void createPackageProductTable() {
        String sql = " CREATE TABLE IF NOT EXISTS PackageProduct (\n"
                    + "     idpackage int PRIMARY KEY NOT NULL,\n"
                    + "     idProducto int NOT NULL \n"  + ")";

        try (Statement stmt = this.conn.createStatement()) {
            stmt.execute(sql);
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }
        
    /*  // Se crea la tabla producto paquete con el campo id como clave primaria
        private void createPackageProductTable() {
            String sql = " CREATE TABLE IF NOT EXISTS packageProduct (\n"
                        + "     idProduct int PRIMARY KEY NOT NULL AUTO_INCREMENT,\n"
                        + "     name text NOT NULL \n"
                        + "     description text NOT NULL \n"
                        + "     stock int NOT NULL,\n"
                        + "     valuePoints int NOT NULL \n" + ");";

            try (Statement stmt = this.conn.createStatement()) {
                stmt.execute(sql);
            } catch (SQLException e) {
                System.out.println(e.getMessage());
            }
        } */
        
        // Se crea la tabla categoria con el campo id como clave primaria
        private void createCategoryTable() {
            String sql = " CREATE TABLE IF NOT EXISTS CategoryEmployee (\n"
                    + "     idCategory int PRIMARY KEY NOT NULL,\n"
                    + "     nameCategory text NOT NULL,\n"
                    + "     valuePoints int NOT NULL \n )";

            try (Statement stmt = this.conn.createStatement()) {
                stmt.execute(sql);
            } catch (SQLException e) {
                System.out.println(e.getMessage());
            }
        }
        
        
        
        
        


}
