package com.grupoassa.gapuntos.entidades;

import java.util.ArrayList;

public class Administrador extends Usuario{

    
    public Administrador(int idUsuario,String nombre, String apellido, String mail,String contrasenia) {
        super(idUsuario,nombre,apellido,mail,contrasenia);        
    }
    
    // Ac� tengo que ver donde hago la verificacion de que exista o no el producto.
    public boolean altaProducto(ArrayList<Producto> catalogo, Producto prod){
        boolean create = false;
        if(catalogo.contains(prod))
            this.actualizarCatalogo(catalogo, prod); /////ver que se puede hacer ac�.
        else{
            catalogo.add(prod);
        }
        return create;
    }
    
    ///Doy de baja un producto 
    public boolean bajaProducto(ArrayList<Producto> catalogo, Producto removeProd){
        boolean exit = false;
        if(catalogo.contains(removeProd)){
            catalogo.remove(removeProd);
            exit = true;
        }
        return exit;
    }
    //Le hago get de producto afuera y set para actualizar campos.
    public boolean actualizarCatalogo(ArrayList<Producto> catalogo, Producto producto){
        /// Actualizo el catalogo reemplazando el producto existente por el actualizado.
        ///Lo hago as� para no tener que hacer varios m�todos sobrecargados para cada campo a actualizar.
        int index = catalogo.indexOf(producto);
        boolean update = false;
        if(index != -1){
            catalogo.remove(index);
            catalogo.add(producto);
            update = true;
        }
        return update;
        
    }
}
