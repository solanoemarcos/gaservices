package com.grupoassa.gapuntos.repositories;

import com.grupoassa.gapuntos.entidades.Producto;
import com.grupoassa.gapuntos.entidades.ProductoPaquete;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


public class PackageProductRepository extends DBConnectionManager{
    
    public PackageProductRepository() {
        super();
    }
    
    // Realiza la insercion de datos iniciales
    public void inserTProductInitial(String sql) { ///ver como hacer los insert a mano
            /* String sql = "INSERT INTO Product(idProduct,name,descripcion,stock,vPuntos) VALUES('1','Arvejas','lata','2','13'),"
                            + "('2','Tomate','caja','4','8')," 
                            + "('3','Albahca','atado','5','9');"; */
            try (PreparedStatement pstmt = this.conn.prepareStatement(sql)) {
                    pstmt.executeUpdate();
                    System.out.println("Insert Initial Product OK");
            } catch (SQLException e) {
                    System.out.println(e.getMessage());
            }
    }

    // Inserta un producto, pasando como parametro una instancia de producto
    public void insertPackageProduct(ProductoPaquete prod) {
            String sql = "INSERT INTO Product(idPackage,idProduct) VALUES(?,?)";

            try (PreparedStatement pstmt = this.conn.prepareStatement(sql)) {
                    pstmt.setInt(1, prod.getIdProducto());
                    pstmt.setString(3, prod.getNombreProd());
                    pstmt.executeUpdate();
                    System.out.println("Insert Product OK");
            } catch (SQLException e) {
                    System.out.println(e.getMessage());
            }
    }
    
    // Retorna un producto buscandolo por id
    public Producto getProduct(int id) {
        String sql = "SELECT *  FROM Product WHERE idProduct=?";
        Producto product = null;
        try (PreparedStatement pstmt = this.conn.prepareStatement(sql)) {
                pstmt.setInt(1, id);
                ResultSet rs = pstmt.executeQuery();
                product = new Producto(0, rs.getString("name"), rs.getString("description"), rs.getInt("stock"),
                             rs.getInt("valuePoints"));
        } catch (SQLException e) {
                System.out.println(e.getMessage());
        }
        return product;
    }

    //Verifica si el producto existe previamente
    //Si existe realiza el update, sino existe lo inserta en la base de datos
    public void insertOrUpdateProduct(Producto product) {
            Producto existProduct = this.getProduct(product.getIdProducto());
            if (existProduct == null) {//Si la variable existProduct es null es porque no existe el producto en la BD.
                    String sql = "INSERT INTO Product(idProduct,name,description,stock,valuePoints) VALUES(?,?,?,?,?)";
                    try (PreparedStatement pstmt = this.conn.prepareStatement(sql)) {
                            pstmt.setInt(1, product.getIdProducto());
                            pstmt.setString(2, product.getNombreProd());
                            pstmt.setString(3, product.getDescripcion());
                            pstmt.setInt(4, product.getStock());
                            pstmt.setInt(5, product.getVPuntos());
                            pstmt.executeUpdate();
                            System.out.println("Insert Product OK");
                    } catch (SQLException e) {
                            System.out.println(e.getMessage());
                    }
            } else {
                    String sql = "UPDATE Product SET idProduct=?,name=?,description=?,stock=?,valuePoints=? WHERE idProduct=?";
                    try (PreparedStatement pstmt = this.conn.prepareStatement(sql)) {
                            pstmt.setInt(1, product.getIdProducto());
                            pstmt.setString(2, product.getNombreProd());
                            pstmt.setString(3, product.getDescripcion());
                            pstmt.setInt(4, product.getStock());
                            pstmt.setInt(5, product.getVPuntos());
                            pstmt.executeUpdate();
                            System.out.println("Update Product OK");
                    } catch (SQLException e) {
                            System.out.println(e.getMessage());
                    }
            }
    } 
}
