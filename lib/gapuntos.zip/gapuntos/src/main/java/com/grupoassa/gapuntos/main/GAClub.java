package com.grupoassa.gapuntos.main;

import com.grupoassa.gapuntos.interfaces.Insertable;

import com.grupoassa.gapuntos.entidades.Administrador;
import com.grupoassa.gapuntos.entidades.Empleado;
import com.grupoassa.gapuntos.entidades.Producto;
import com.grupoassa.gapuntos.entidades.ProductoPaquete;
import com.grupoassa.gapuntos.entidades.Operacion;
import com.grupoassa.gapuntos.entidades.ProductoOferta;

import java.io.BufferedWriter;
import java.io.FileReader;

import java.io.IOException;

import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;


import java.text.ParseException;
import java.text.SimpleDateFormat;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Properties;

import java.util.Set;

import com.grupoassa.gapuntos.repositories.AdminRepository;
import com.grupoassa.gapuntos.repositories.DBConnectionManager;
import com.grupoassa.gapuntos.repositories.EmployeeRepository;
import com.grupoassa.gapuntos.repositories.OperationRepository;
import com.grupoassa.gapuntos.repositories.ProductRepository;


public class GAClub {
    private ArrayList<Producto> catalogoProd;
    private ArrayList<Empleado> empleados;
    private ArrayList<Administrador> administradores;
    private ArrayList<Operacion> operaciones;
    
    public GAClub() {
        this.catalogoProd = new ArrayList<Producto>();
        this.empleados = new ArrayList<Empleado>();
        this.administradores = new ArrayList<Administrador>();
        this.operaciones = new ArrayList<Operacion>();
    }
    

    
    public java.util.Date convertStringToDate(String newDate){
        SimpleDateFormat date = new SimpleDateFormat("dd/MM/yyyy");
        java.util.Date dateT = null;
        try {
            dateT =  date.parse(newDate);
        } catch (ParseException e) {
        }
        return dateT;
    }
    
    public void writeFileOperations(java.util.Date beginMonth, java.util.Date endMonth){
        Path path = Paths.get("gAClub_MonthOperations.txt");
        try (BufferedWriter br = Files.newBufferedWriter(path,
                    Charset.defaultCharset(), StandardOpenOption.CREATE)) {
                 for (Operacion line : this.operaciones) {
                     if(((line.getFechaTransaccion().compareTo(beginMonth))>=0) && ((line.getFechaTransaccion().compareTo(endMonth))<= 0)) 
                        br.write(line.toString());
                        br.newLine();
                 }
              } catch (Exception e) {
                 e.printStackTrace();
                }
    
    }
    
    public void listProductByStock(ArrayList<Producto> productos){
        Object[] prodOrd= productos.toArray();
        Arrays.sort(prodOrd);
        for(Object prod : prodOrd){
            System.out.println(prod.toString());
        }
    }    
    
    public void listarOperacionesEmpleado(Empleado emp){
        for(Operacion op : this.operaciones)
            if(emp.getDniUsuario().compareTo(op.getDniEmpleado()) == 0)
                System.out.println(op.toString() + "\n");
                
    }
    
    public void addExchange(Empleado emp, Producto prod, java.util.Date fechaTrans, Integer idOp){
        try{
            boolean success = emp.canjearPuntos(emp, prod, fechaTrans);
            if (success){
                Operacion transaccion = new Operacion(idOp, emp.getDniUsuario(), prod.getIdProducto(), fechaTrans, prod.getVPuntos());
                this.operaciones.add(transaccion);
            }
        }catch (Exception e){
            e.printStackTrace();
        }
        
    }
    
    public void saveOnDataBase(ArrayList list, Insertable nChain){
        for(Object chain: list){
            nChain.insertOrUpdateObject(chain);
        }
    }
    
//***************************************************  MAIN ********************************************************//    
   
    public static void main(String[] args) {
        DBConnectionManager dbConn = new DBConnectionManager();
        GAClub gaClub = new GAClub();
        Properties p = new Properties();
        try {
            p.load(new FileReader("puntosCategoria.properties"));
        } catch (IOException e) {
            System.out.println("An error occurred when reading from the configuration file.");
    }
        
    

//************************************************* CREACION DE OBJETOS **********************************************//


        Empleado emp1 = new Empleado(33456789,"Jorge","Sardon","jsardon@gmail.com","65343298","Consultor_Experimentado",
                         gaClub.convertStringToDate("06/03/2014"), Integer.parseInt(p.getProperty("Consultor_Experimentado")));

        Empleado emp2 = new Empleado(35562462,"Jud","Montoya","montoyajudit@gmail.com","86592hjn","Asistente",
                         gaClub.convertStringToDate("06/03/2018"), Integer.parseInt(p.getProperty("Asistente")));
        
        Empleado emp3 = new Empleado(35123789,"Leandro","Tapia","jlatpia@gmail.com","84750293","Consultor_Experimentado",
                         gaClub.convertStringToDate("06/03/2016"), Integer.parseInt(p.getProperty("Consultor_Senior")));
        
        Empleado emp4 = new Empleado(34345718,"Marcos","Solano","mesolano@gmail.com","kdsgndsk889a","Lider",
                         gaClub.convertStringToDate("06/03/2015"), Integer.parseInt(p.getProperty("Lider")));
        
        Empleado emp5 = new Empleado(37870567,"Sofia","Sprovieri","ssprovieri@gmail.com","aj8459348lgoa","Asistente",
                         gaClub.convertStringToDate("06/03/2018"), Integer.parseInt(p.getProperty("Consultor")));
        
       
        Producto prod1 = new Producto(1, "Tomate", "natural", 3, 1);
        Producto prod2 = new Producto(2, "Albahaca", "atado", 5, 3);
        Producto prod3 = new Producto(3, "Queso", "cremoso", 7, 5);
        Producto prod4 = new Producto(4, "Pan", "miga", 9, 8);
        Producto prod5 = new Producto(5, "Tarta", "hojaldre", 11, 13);
        Producto prod6 = new Producto(6, "Pizza", "rellena", 13, 15);
        
        
        ////// Producto Oferta
        Producto prodOf = new ProductoOferta(prod3.getIdProducto(),prod3,gaClub.convertStringToDate("05/10/2018"),20.0);

        Set<Producto> combo = new HashSet<Producto>();
        combo.add(prod1);
        combo.add(prod2);
        combo.add(prod3);
        combo.add(prod6);
        Producto packProd1 = new ProductoPaquete(1,"ComboMax", "Pizza rellena caprese", combo);
        
        
        //Asumo que todos los empleados que hacen trasacciones, lo hacen luego de tener un usuario y haber ingresado a la empresa.!!!!!
        Operacion operation1 = new Operacion (1, emp2.getDniUsuario(), prod1.getIdProducto(), gaClub.convertStringToDate("01/04/2014"),
                          prod1.getVPuntos());
        Operacion operation2 = new Operacion (2, emp5.getDniUsuario(), prod3.getIdProducto(), gaClub.convertStringToDate("01/05/2018"),
                          prod3.getVPuntos());
        Operacion operation3 = new Operacion (3, emp4.getDniUsuario(), prod5.getIdProducto(), gaClub.convertStringToDate("05/06/2015"),
                          prod5.getVPuntos());
        Operacion operation4 = new Operacion (4, emp1.getDniUsuario(), prod2.getIdProducto(), gaClub.convertStringToDate("05/07/2018"),
                          prod2.getVPuntos());
        Operacion operation5 = new Operacion (5, emp3.getDniUsuario(), prod4.getIdProducto(), gaClub.convertStringToDate("05/08/2018"),
                          prod4.getVPuntos());
        
        Administrador admin1 = new Administrador(14629414,"Laura","Albizu","mlalbizu@grupoassa.com","ga2018");
        Administrador admin2 = new Administrador(32236543,"Roc�o","Costa","rhcosta@grupoassa.com","ga2017");
        Administrador admin3 = new Administrador(45698382,"Aldana","Ruiz","raldana@grupoassa.com","grupoassa09");
        
//************************************* INSERCION DE INFO A LA BASE DE DATOS *****************************************//       
      
        
        ProductRepository prodRep = new ProductRepository();
        prodRep.insertProduct(prod1);
        prodRep.insertProduct(prod2);
        prodRep.insertProduct(prod3);
        prodRep.insertProduct(prod4);
        prodRep.insertProduct(prod5);
        prodRep.insertProduct(prod6);

        
        EmployeeRepository empRep = new EmployeeRepository();
        empRep.insertEmployee(emp1);
        empRep.insertEmployee(emp2);
        empRep.insertEmployee(emp3);
        empRep.insertEmployee(emp4);
        empRep.insertEmployee(emp5);
        
        AdminRepository adminRep = new AdminRepository();
        adminRep.insertAdmin(admin1);
        adminRep.insertAdmin(admin2);        
        
        //Hacer las validaciones para la carga correcta de operacionnes, si se puede o no hacer.
        
        OperationRepository opRep = new OperationRepository();
        opRep.insertOperation(operation1);
        opRep.insertOperation(operation2);
        opRep.insertOperation(operation3);
        opRep.insertOperation(operation4);
        opRep.insertOperation(operation5);
         
        
      
//**************************************** RECUPERACION DE DATOS *****************************************************//


        gaClub.catalogoProd.addAll(prodRep.getProducts());        
        Producto prod7 = new Producto(7,"Agua","Mineral",4,9);
        

        System.out.println("\n*************************************\n");
        
        ///***************************Para hacer pruebas*******************************//
        
        /* admin1.altaProducto(gaClub.catalogoProd, prod7); 
        adminRep.insertAdmin(admin3);
        prodRep.deleteRow(gaClub.catalogoProd.get(3).getIdProducto(), "DELETE FROM Product WHERE idProduct =?");
        admin2.bajaProducto(gaClub.catalogoProd, gaClub.catalogoProd.get(3));
        gaClub.listProductByStock(gaClub.catalogoProd);
        gaClub.addExchange(gaClub.empleados.get(2), gaClub.catalogoProd.get(4),gaClub.convertStringToDate("21/05/2018"),6); */ 
        
        
        

        gaClub.empleados.addAll(empRep.getEmployees());
        gaClub.administradores.addAll(adminRep.getAdmins());
        gaClub.operaciones.addAll(opRep.getOperations());
        
        gaClub.listProductByStock(gaClub.catalogoProd);
        gaClub.listarOperacionesEmpleado(emp3);
        gaClub.writeFileOperations(gaClub.convertStringToDate("05/07/2018"),gaClub.convertStringToDate("06/08/2018")); 
        
        
        
        
//********************************************** GUARDADO EN LA BASE DE DATOS ****************************************//
        
    
        gaClub.saveOnDataBase(gaClub.catalogoProd, prodRep);
        gaClub.saveOnDataBase(gaClub.operaciones, opRep);
        gaClub.saveOnDataBase(gaClub.empleados, empRep);
        gaClub.saveOnDataBase(gaClub.administradores, adminRep);
        
        
    
    }

}



       


