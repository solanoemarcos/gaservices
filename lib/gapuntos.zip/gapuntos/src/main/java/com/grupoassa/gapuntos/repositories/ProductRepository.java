package com.grupoassa.gapuntos.repositories;

import com.grupoassa.gapuntos.interfaces.Insertable;

import com.grupoassa.gapuntos.entidades.Producto;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import java.util.ArrayList;
import java.util.List;


public class ProductRepository extends DBConnectionManager implements Insertable{
    
    public ProductRepository() {
        super();
    }
    
    // Realiza la insercion de datos iniciales
    public void inserTProductInitial(String sql) {
            /* String sql = "INSERT INTO Product(idProduct,name,descripcion,stock,vPuntos) VALUES('1','Arvejas','lata','2','13'),"
                            + "('2','Tomate','caja','4','8')," 
                            + "('3','Albahca','atado','5','9');"; */
            try (PreparedStatement pstmt = this.conn.prepareStatement(sql)) {
                    pstmt.executeUpdate();
                    System.out.println("Insert Initial Product OK");
            } catch (SQLException e) {
                    System.out.println(e.getMessage());
            }
    }

    // Inserta un producto, pasando como parametro una instancia de producto
    public void insertProduct(Producto prod) {
            String sql = "INSERT INTO Product(idProduct,name,description,stock,valuePoints) VALUES(?,?,?,?,?)";

            try (PreparedStatement pstmt = this.conn.prepareStatement(sql)) {
                    pstmt.setInt(1, prod.getIdProducto());
                    pstmt.setString(2, prod.getNombreProd());
                    pstmt.setString(3, prod.getDescripcion());
                    pstmt.setInt(4, prod.getStock());
                    pstmt.setInt(5, prod.getVPuntos());
                    pstmt.executeUpdate();
                    System.out.println("Insert Product OK");
            } catch (SQLException e) {
                    System.out.println(e.getMessage());
            }
    }
    
    // Retorna un producto buscandolo por id
    public Producto getProduct(int id) {
        String sql = "SELECT *  FROM Product WHERE idProduct=?";
        Producto product = null;
        try (PreparedStatement pstmt = this.conn.prepareStatement(sql)) {
                pstmt.setInt(1, id);
                ResultSet rs = pstmt.executeQuery();
                product = new Producto(rs.getInt("idProduct"), rs.getString("name"), rs.getString("description"), rs.getInt("stock"),
                             rs.getInt("valuePoints"));
        } catch (SQLException e) {
                System.out.println(e.getMessage());
        }
        return product;
    }

    //Verifica si el producto existe previamente
    //Si existe realiza el update, sino existe lo inserta en la base de datos
    public void insertOrUpdateObject(Object chain) {
            Producto product = (Producto) chain;
            Producto existProduct = this.getProduct(product.getIdProducto());
            if (existProduct == null) //Si la variable existProduct es null es porque no existe el producto en la BD.
                    this.insertProduct(product);
             else {
                    String sql = "UPDATE Product SET name=?,description=?,stock=?,valuePoints=? WHERE idProduct=?";
                    try (PreparedStatement pstmt = this.conn.prepareStatement(sql)) {
                            pstmt.setInt(5, product.getIdProducto());
                            pstmt.setString(1, product.getNombreProd());
                            pstmt.setString(2, product.getDescripcion());
                            pstmt.setInt(3, product.getStock());
                            pstmt.setInt(4, product.getVPuntos());
                            pstmt.executeUpdate();
                            System.out.println("Update Product OK");
                    } catch (SQLException e) {
                            System.out.println(e.getMessage());
                    }
            }
    } 

    // Retorna una lista de con todos los productos en la base
    public List<Producto> getProducts() {
            String sql = "SELECT *  FROM Product"; 
            List<Producto> products = new ArrayList<Producto>();

            try (Statement stmt = this.conn.createStatement();
                            ResultSet rs = stmt.executeQuery(sql)) {
                    while (rs.next()) {
                            Producto product = new Producto(rs.getInt("idProduct"), rs.getString("name"), rs.getString("description"), rs.getInt("stock"),
                                 rs.getInt("valuePoints"));
                            products.add(product);
                    }
            } catch (SQLException e) {
                    System.out.println(e.getMessage());
            }
            return products;
    }
    
    public void deleteRow(int id,String sql){
        try (PreparedStatement pstmt = this.conn.prepareStatement(sql)) {
                pstmt.setInt(1, id);
                pstmt.executeUpdate();
            System.out.println("Delete Product OK");
        } catch (SQLException e) {
                System.out.println(e.getMessage());
        }
    }
}
