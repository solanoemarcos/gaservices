package com.grupoassa.gapuntos.entidades;

import java.text.SimpleDateFormat;

import java.time.LocalDate;

import java.util.Date;

public class Operacion implements Comparable{
    private Integer idOperacion;
    private Integer idProducto;
    private Integer dniEmpleado;
    private Date fechaTransaccion;
    private int puntosCanje;

        public void setIdOperation(int idOperation) {
        this.idOperacion = idOperation;
    }

    public int getIdOperation() {
        return idOperacion;
    }

    public Operacion(Integer idOperacion, Integer empleado, Integer producto, Date fechaTransaccion,
                     int puntosCanje) {
        
        this.idOperacion = idOperacion;
        this.dniEmpleado = empleado;
        this.idProducto = producto;
        this.fechaTransaccion = fechaTransaccion;
        this.puntosCanje = puntosCanje;
        
    }

    public void setIdProducto(Integer producto) {
        this.idProducto = producto;
    }

    public Integer getIdProducto() {
        return idProducto;
    }

    public void setDniEmpleado(Integer empleado) {
        this.dniEmpleado = empleado;
    }

    public Integer getDniEmpleado() {
        return dniEmpleado;
    }

    public void setFechaTransaccion(Date fechaTransaccion) {
        this.fechaTransaccion = fechaTransaccion;
    }

    public Date getFechaTransaccion() {
        return fechaTransaccion;
        
    }

    public void setPuntosCanje(int puntosCanje) {
        this.puntosCanje = puntosCanje;
    }

    public int getPuntosCanje() {
        return puntosCanje;
    }
    
    public void realizarTransaccion(Integer emp, Integer prod, Date fecha, Integer puntosCanje){
        this.dniEmpleado = emp;
        this.idProducto = prod; 
        this.fechaTransaccion = fecha;
        this.puntosCanje = puntosCanje;
    }
     
    public String getDateToString(Date newDate){
        SimpleDateFormat date = new SimpleDateFormat("dd/MM/yyyy");
        String fechaComoCadena = date.format(newDate);
        return fechaComoCadena;
    }
    
    public String toString(){
        return this.idOperacion+" | "+ this.idProducto +" | "+ this.dniEmpleado 
                                +" | "+ this.getDateToString(this.fechaTransaccion)+" | "+ this.puntosCanje+" puntos";
    }
    
    @Override
    public int compareTo(Object o) {
        return this.fechaTransaccion.compareTo(((Operacion)o).getFechaTransaccion());
    }

}
