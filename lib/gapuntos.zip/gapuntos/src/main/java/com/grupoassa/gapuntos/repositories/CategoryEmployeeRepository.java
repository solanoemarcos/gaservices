package com.grupoassa.gapuntos.repositories;


import com.grupoassa.gapuntos.entidades.CategoriaEmpleado;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import java.util.ArrayList;
import java.util.List;

public class CategoryEmployeeRepository extends DBConnectionManager {
    public CategoryEmployeeRepository() {
        super();
    }
    // Realiza la insercion de datos iniciales
    public void insertCategoryInitial(String sql) {
            /* String sql = "INSERT INTO CategoryEmployee (id,category, points) VALUES('1','Juan','Lopez'),"
                            + "('2','Lucas','Fernandez')," 
                            + "('3','Roberto','Gutierrez');"; */
            try (PreparedStatement pstmt = this.conn.prepareStatement(sql)) {
                    pstmt.executeUpdate();
                    System.out.println("Insert Initial Category OK");
            } catch (SQLException e) {
                    System.out.println(e.getMessage());
            }
    }

    // Inserta una categor�a, pasando como parametro una instancia de categor�a
    public void insertAdmin(CategoriaEmpleado category) {
            String sql = "INSERT INTO CategoryEmployee (id,category,points) VALUES(?,?,?)";

            try (PreparedStatement pstmt = this.conn.prepareStatement(sql)) {
                    pstmt.setInt(1, category.getIdCategoria());
                    pstmt.setString(2, category.getCategoria());
                    pstmt.setInt(3, category.getPuntos());
                    pstmt.executeUpdate();
                    System.out.println("Insert Category OK");
            } catch (SQLException e) {
                    System.out.println(e.getMessage());
            }
    }
    
    // Retorna un administrador buscandolo por id
    public CategoriaEmpleado getCategory(int id) {
        String sql = "SELECT *  FROM CategoryEmployee WHERE id=?";
        CategoriaEmpleado category = null;
        try (PreparedStatement pstmt = this.conn.prepareStatement(sql)) {
                pstmt.setInt(1, id);
                ResultSet rs = pstmt.executeQuery();
                category = new CategoriaEmpleado (rs.getInt("id"), rs.getString("category"), rs.getInt("points"));
        } catch (SQLException e) {
                System.out.println(e.getMessage());
        }
        return category;
    }

    //Verifica si la categoria existe previamente
    //Si existe realiza el update, sino existe la inserta en la base de datos
    public void insertOrUpdateCategory(CategoriaEmpleado category) {
            CategoriaEmpleado existCategory = this.getCategory(category.getIdCategoria());
            if (existCategory == null) {//Si la variable existCategory es null es porque no existe la categoria en la BD.
                    String sql = "INSERT INTO Category(id,category,points) VALUES(?,?,?)";
                    try (PreparedStatement pstmt = this.conn.prepareStatement(sql)) {
                            pstmt.setInt(1, category.getIdCategoria());
                            pstmt.setString(2, category.getCategoria());
                            pstmt.setInt(3, category.getPuntos());
                            pstmt.executeUpdate();
                            System.out.println("Insert Category OK");
                    } catch (SQLException e) {
                            System.out.println(e.getMessage());
                    }
            } else {
                    String sql = "UPDATE Category SET category=?,points=? WHERE id=?";
                    try (PreparedStatement pstmt = this.conn.prepareStatement(sql)) {
                            pstmt.setInt(1, category.getIdCategoria());
                            pstmt.setString(2, category.getCategoria());
                            pstmt.setInt(3, category.getPuntos());
                            pstmt.executeUpdate();
                            System.out.println("Update Category OK");
                    } catch (SQLException e) {
                            System.out.println(e.getMessage());
                    }
            }
    }



    // Retorna una lista de con todos los administrador en la base
    public List<CategoriaEmpleado> getCategories() {
            String sql = "SELECT *  FROM Category";
            List<CategoriaEmpleado> categories = new ArrayList<CategoriaEmpleado>();

            try (Statement stmt = this.conn.createStatement();
                            ResultSet rs = stmt.executeQuery(sql)) {
                    while (rs.next()) {
                            CategoriaEmpleado category = new CategoriaEmpleado(rs.getInt("id"), rs.getString("category"), rs.getInt("points"));
                            categories.add(category);
                    }
            } catch (SQLException e) {
                    System.out.println(e.getMessage());
            }
            return categories;
    }
}
