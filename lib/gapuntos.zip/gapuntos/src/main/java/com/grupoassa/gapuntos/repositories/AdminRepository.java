package com.grupoassa.gapuntos.repositories;


import com.grupoassa.gapuntos.entidades.Administrador;
import com.grupoassa.gapuntos.entidades.Usuario;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import java.util.ArrayList;
import java.util.List;

public class AdminRepository extends UserRepository{

    public AdminRepository() {
        super();
    }

	// Realiza la insercion de datos iniciales
	public void insertAdminInitial(String sql) {
		/* String sql = "INSERT INTO Admin(id,name,lastName) VALUES('1','Juan','Lopez'),"
				+ "('2','Lucas','Fernandez')," 
				+ "('3','Roberto','Gutierrez');"; */
		try (PreparedStatement pstmt = this.conn.prepareStatement(sql)) {
			pstmt.executeUpdate();
			System.out.println("Insert Initial Admin OK");
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
	}

	// Inserta un administrador, pasando como parametro una instancia de administrador
	public void insertAdmin(Usuario admin) {
		String sql = "INSERT INTO Admin(idAdmin,name,lastName,mail,password) VALUES(?,?,?,?,?)";

		try (PreparedStatement pstmt = this.conn.prepareStatement(sql)) {
			pstmt.setInt(1, admin.getDniUsuario());
			pstmt.setString(2, admin.getNombre());
			pstmt.setString(3, admin.getApellido());
                        pstmt.setString(4, admin.getMail());
                        pstmt.setString(5, admin.getContrasenia());
			pstmt.executeUpdate();
			System.out.println("Insert Admin OK");
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
	}
        
    // Retorna un administrador buscandolo por id
    public Administrador getAdmin(int id) {
            String sql = "SELECT *  FROM Admin WHERE idAdmin=?";
            Administrador admin = null;
            try (PreparedStatement pstmt = this.conn.prepareStatement(sql)) {
                    pstmt.setInt(1, id);
                    ResultSet rs = pstmt.executeQuery();
                    admin = new Administrador(rs.getInt("idAdmin"), rs.getString("name"),
                                    rs.getString("lastName"),rs.getString("mail"),rs.getString("password"));
            } catch (SQLException e) {
                    System.out.println(e.getMessage());
            }
            return admin;
    }

	//Verifica si el administrador existe previamente
	//Si existe realiza el update, sino existe lo inserta en la base de datos
	public void insertOrUpdateObject(Object chain) {
                Usuario admin = (Usuario) chain;
		Usuario existAdmin = this.getAdmin(admin.getDniUsuario());
		if (existAdmin == null) {//Si la variable existAdmin es null es porque no existe el administrador en la BD.
                        this.insertAdmin(admin);
		} else {
			String sql = "UPDATE Admin SET name=?,lastName=?,mail=?,password=? WHERE idAdmin=?";
			try (PreparedStatement pstmt = this.conn.prepareStatement(sql)) {
                                pstmt.setInt(5, admin.getDniUsuario());
				pstmt.setString(1, admin.getNombre());
				pstmt.setString(2, admin.getApellido());
                                pstmt.setString(3, admin.getMail());
                                pstmt.setString(4, admin.getContrasenia());
				pstmt.executeUpdate();
				System.out.println("Update Admin OK");
			} catch (SQLException e) {
				System.out.println(e.getMessage());
			}
		}
	}



	// Retorna una lista de con todos los administrador en la base
	public List<Administrador> getAdmins() {
		String sql = "SELECT *  FROM Admin";
		List<Administrador> admins = new ArrayList<Administrador>();

		try (Statement stmt = this.conn.createStatement();
				ResultSet rs = stmt.executeQuery(sql)) {
			while (rs.next()) {
				Administrador admin = new Administrador(rs.getInt("idAdmin"),
						rs.getString("name"), rs.getString("lastName"),rs.getString("mail"),rs.getString("password"));
				admins.add(admin);
			}
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		return admins;
	}


    @Override
    public PreparedStatement preparedStatementInsert(String sql, Object thing) throws SQLException {
        // TODO Implement this method
        return null;
    }

    @Override
    public PreparedStatement preparedStatementUpdate(String sql, Object thing) throws SQLException {
        // TODO Implement this method
        return null;
    }
}
