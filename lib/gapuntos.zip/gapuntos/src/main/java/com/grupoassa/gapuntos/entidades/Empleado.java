package com.grupoassa.gapuntos.entidades;

import com.grupoassa.gapuntos.excepciones.PuntosInsuficientesException;
import com.grupoassa.gapuntos.excepciones.StockInsuficienteException;

import java.text.SimpleDateFormat;

import java.util.Date;

public class Empleado extends Usuario {

    private String categoria;
    private java.util.Date fechaDeIngreso;
    private Integer puntos;

    public Empleado(int idUsuario, String nombre, String apellido, String mail, String contrasenia, String categoria, Date fechaDeIngreso, Integer puntos) {
        super(idUsuario, nombre, apellido, mail, contrasenia);
        this.categoria = categoria;
        this.fechaDeIngreso = fechaDeIngreso;
        this.puntos = puntos;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public String getCategoria() {
        return this.categoria;
    }

    public void setFechaDeIngreso(Date fechaDeIngreso) {
        this.fechaDeIngreso = fechaDeIngreso;
    }

    public java.util.Date getFechaDeIngreso() {
        return fechaDeIngreso;
    }

    public void setPuntos(Integer puntos) {
        this.puntos = puntos;
    }

    public Integer getPuntos() {
        return puntos;
    }

    @Override
    public String toString() {
        return super.toString() + " " + this.fechaDeIngreso + " | " + this.categoria + " | Puntos: " + this.puntos;
    }

    public String dateToString(Date newDate) {
        SimpleDateFormat date = new SimpleDateFormat("dd/MM/yyyy");
        String fechaComoCadena = date.format(newDate);
        return fechaComoCadena;
    }

    public boolean canjearPuntos(Empleado emp, Producto prod, Date fechaDeTransaccion) throws PuntosInsuficientesException, StockInsuficienteException {
        boolean operacion = false;
        if (emp.getPuntos() > prod.getVPuntos()) {
            if (prod.getStock() > 0) {
                //emp.getPuntos() -= prod.getVPuntos();
                /*                    op.realizarTransaccion(emp.getDniUsuario(), prod.getIdProducto(), fechaDeTransaccion,prod.getVPuntos()); */
                operacion = true;
            } else {
                throw new StockInsuficienteException();
            }
        } else {
            throw new PuntosInsuficientesException();
        }

        return operacion;
    }
}
